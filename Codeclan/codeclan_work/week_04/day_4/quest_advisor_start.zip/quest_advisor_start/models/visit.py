class Visit:

    def __init__( self, user, location, review, id = None ):
        self.user = user
        self.location = location
        self.review = review
        self.id = id

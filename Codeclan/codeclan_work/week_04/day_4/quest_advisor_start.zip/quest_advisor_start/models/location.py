class Location:

    def __init__(self, name, category, id = None):
      self.name = name
      self.category = category
      self.id = id

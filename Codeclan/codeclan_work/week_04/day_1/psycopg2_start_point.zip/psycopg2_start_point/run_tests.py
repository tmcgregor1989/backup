import unittest
 
from tests.task_test import TestTask
 
 
if __name__ == '__main__':
    unittest.main()
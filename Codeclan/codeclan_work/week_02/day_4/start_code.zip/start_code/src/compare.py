def compare():
    pass

import unittest
from tests.compare_test import TestCompare

if __name__ == '__main__':
    unittest.main()

import unittest

from tests.car_test import TestCar
from tests.motorbike_test import TestMotorbike

if __name__ == '__main__':
    unittest.main()
